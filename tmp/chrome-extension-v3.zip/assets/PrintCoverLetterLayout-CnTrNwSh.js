import{r as s,j as r}from"./react-vendor-CtSXPY5C.js";import{u as _}from"./index-CNhdFlpJ.js";import{C as c}from"./CoverLetterRender-CByIab7i.js";import"./router-BOiHHRgT.js";import"./motion-lwwOCkxh.js";import"./observability-DnIEDzQr.js";function v(){const{coverLetter:i}=_(),[e,n]=s.useState(null);if(s.useEffect(()=>{const a=()=>{window.__INJECTED_COVER_LETTER_DATA__&&n(window.__INJECTED_COVER_LETTER_DATA__)};return window.__INJECTED_COVER_LETTER_DATA__?n(window.__INJECTED_COVER_LETTER_DATA__):i&&n(i),window.addEventListener("coverLetterDataReady",a),()=>window.removeEventListener("coverLetterDataReady",a)},[i]),!e)return r.jsx("div",{className:"min-h-screen bg-white"});const o=e.settings||{selected_template:"classic_ats",font:"Arial",font_size:11,line_height:1.65,paragraph_spacing:18,page_margin:20,paper_size:"A4",theme_color:"#1d4ed8"},m=o.selected_template||e.template_name||"classic_ats",t=o.paper_size==="Letter"?{width:"215.9mm",minHeight:"279.4mm",css:"Letter"}:{width:"210mm",minHeight:"297mm",css:"A4"},d=e.generated_cover_letter||e.cover_letter||e;return r.jsxs(r.Fragment,{children:[r.jsx("style",{children:`
        @page { size: ${t.css}; margin: 0; }
        html, body, #root { margin: 0; padding: 0; background: white; }
        .cover-letter-page {
          width: ${t.width};
          min-height: ${t.minHeight};
          max-width: none;
          margin: 0;
          transform: none !important;
          zoom: 1 !important;
          box-sizing: border-box;
        }
        @media print {
          html, body, #root {
            width: ${t.width};
            min-height: ${t.minHeight};
          }
        }
      `}),r.jsx("main",{id:"resume-print-container",className:"cover-letter-page bg-white",style:{width:t.width,minHeight:t.minHeight},children:r.jsx(c,{coverLetter:d,context:e.context,templateKey:m,settings:o,className:"shadow-none border-none p-12 md:p-14"})})]})}export{v as default};
